from premade_pieces import plain_wall as muro_vuoto
from premade_pieces import entrance as entrata
from premade_pieces import icy_wall as muro_ghiacciato
from premade_pieces import magical_wall as muro_magico
from premade_pieces import simple_battlement as merlatura_semplice
from premade_pieces import magical_battlement as merlatura_magica

# to avoid errors if people have old versions and not reset cells
from castello import ponte_levatoio