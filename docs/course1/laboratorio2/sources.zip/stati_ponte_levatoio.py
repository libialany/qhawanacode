
# drawbridge states

aperto = True
chiuso = False