from wall_properties import bricks as ziegel
from wall_properties import ivy as efeu
from wall_properties import crack as riss
from wall_properties import nothing as nichts
from wall_properties import door as tuer
from wall_properties import double_door as tor
from wall_properties import window as fenster
from wall_properties import arched_window as rundbogen_fenster

# old version - kept in order to avoid errors if someone has an older version
from wall_properties import arched_window as rundes_fenster