
# wall border states

borders = True
no_borders = False