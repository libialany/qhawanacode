
# wall border states

mit_raendern = True
ohne_raender = False