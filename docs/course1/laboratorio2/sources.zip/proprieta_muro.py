from wall_properties import bricks as mattoni
from wall_properties import ivy as edera
from wall_properties import crack as crepa
from wall_properties import nothing as niente
from wall_properties import door as porta
from wall_properties import double_door as portone
from wall_properties import window as finestra
from wall_properties import arched_window as finestra_arcuata

# old version - kept in order to avoid errors if someone has an older version
from wall_properties import arched_window as finestra_arrotondata