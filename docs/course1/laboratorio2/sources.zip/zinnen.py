from merlons import rectangular_merlon as rechteckige_zinnen
from merlons import rounded_merlon as runde_zinnen
from merlons import split_merlon as gespaltene_zinnen