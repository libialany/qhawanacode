from roof import roof as dach
from battlement import battlement as brustwehr
from wall import wall as mauer
from drawbridge import drawbridge as zugbruecke