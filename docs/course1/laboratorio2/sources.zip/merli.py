from merlons import rectangular_merlon as merlo_rettangolare
from merlons import rounded_merlon as merlo_arrotondato
from merlons import split_merlon as merlo_diviso