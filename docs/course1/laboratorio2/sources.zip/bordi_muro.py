
# wall border states

con_bordi = True
senza_bordi = False