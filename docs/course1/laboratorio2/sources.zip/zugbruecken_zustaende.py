
# drawbridge states

offen = True
geschlossen = False