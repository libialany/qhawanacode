from colors import red as rot
from colors import yellow as gelb
from colors import green as gruen
from colors import cyan
from colors import blue as blau
from colors import purple as lila
from colors import pink as rosarot
from colors import grey as grau
from colors import black as schwarz
from colors import brown as braun