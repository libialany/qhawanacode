
# drawbridge states

opened = True
closed = False