from roof import roof as tetto
from battlement import battlement as merlatura
from wall import wall as muro
from drawbridge import drawbridge as ponte_levatoio