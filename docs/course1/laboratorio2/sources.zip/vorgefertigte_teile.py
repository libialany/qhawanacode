from premade_pieces import plain_wall as einfache_mauer
from premade_pieces import entrance as eingang
from premade_pieces import icy_wall as eismauer
from premade_pieces import magical_wall as magische_mauer
from premade_pieces import simple_battlement as einfache_brustwehr
from premade_pieces import magical_battlement as magische_brustwehr


# to avoid errors if people have old versions and not reset cells
from burg_komponenten import zugbruecke